var express = require("express");
var app = express();
var db = require("./model/db.js");
var formidable = require('formidable');
var crypto = require("crypto");
var cors = require('cors');
var session = require('express-session');
app.use(cors());


app.post("/tijiao", function (req, res, next) {
    var form = new formidable.IncomingForm();

    form.parse(req, function (err, fields) {
    	console.log("收到请求了");
        var md5 = crypto.createHash('md5');
        var subpasswd = md5.update(fields.password).digest('base64');

        db.find("user", {
            "username" : fields.username
        }, function (err, result) {
            if(err){
                console.log("出错了");
                res.send("-2");
                return;
            }
            if(result.length!=0){
                console.log("用户名被占用");
                res.send("-3");
                return;
            }else{
                db.insertOne("user", {
                    "username" : fields.username,
                    "password" : subpasswd
                }, function (err, result) {
                    if(err){
                        res.send("-1");
                        return;
                    }
                    console.log("注册成功");
                    res.send("1");
                });
            }

        });


    });
});
app.post("/login", function (req, res, next) {
    var form = new formidable.IncomingForm();

    form.parse(req, function (err, fields) {
        console.log("收到请求了");
        var md5 = crypto.createHash('md5');
        var subpasswd2 = md5.update(fields.password).digest('base64');
        db.find("user", {
            "username" : fields.username
        }, function (err, result) {
            var passwd = result[0].password;
            if(err){
                console.log("出错了");
                res.send({"result":-1});
                return;
            }
            if(passwd==subpasswd2){
                console.log("登陆成功");

                //req.session.login = "1";
                //req.session.username = fields.username;
                res.send("1");
            }else{
                res.send("-1");
                console.log("密码错误");
            }

        });
    });
});

app.listen(3000);