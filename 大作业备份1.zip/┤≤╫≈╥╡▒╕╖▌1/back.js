var express = require("express");
var app = express();
var db = require("./model/db.js");
var formidable = require('formidable');

app.post("/tijiao", function (req, res, next) {
    var form = new formidable.IncomingForm();

    form.parse(req, function (err, fields) {
    	console.log("收到请求了");
        db.insertOne("user", {
            "username" : fields.username,
            "password" : fields.password
        }, function (err, result) {
            if(err){
                res.send({"result":-1});
                return;
            }
            console.log("注册成功");
            res.send({"result":1});
        });
    });
});
app.post("/login", function (req, res, next) {
    var form = new formidable.IncomingForm();

    form.parse(req, function (err, fields) {
        console.log("收到请求了");
        console.log(fields);
        db.find("user", {
            "username" : fields.username
        }, function (err, result) {
            var passwd = result[0].password;
            if(err){
                console.log("出错了");
                res.send({"result":-1});
                return;
            }
            if(passwd==fields.password){
                console.log("登陆成功");
                res.send({"result":1});
            }else{
                console.log("密码错误");
            }

        });
    });
});
app.listen(3000);