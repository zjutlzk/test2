/**
 * Created by lenovo on 2018/6/8.
 */
var MongoClient = require('mongodb').MongoClient;
function connectDB(callback) {
    var url = 'mongodb://localhost:27017/haha';
    MongoClient.connect(url, function (err, db) {
        if (err) {
            console.log("出错了！");
            return;
        }
        console.log("连接成功");
        callback(err,db);
    });
}

exports.insertOne = function (collectionName, json, callback) {
    connectDB(function (err, db) {
        const mydb = db.db("haha");
        mydb.collection(collectionName).insertOne(json, function (err, result) {
            callback(err, result);
            db.close();
        })
    })
};

exports.find = function (collectionName, json,callback) {
    var result = [];
    connectDB(function (err, db) {
        const mydb = db.db("haha");
        var cursor = mydb.collection(collectionName).find(json);
        cursor.each(function (err, doc) {
            if (err) {
                callback(err, null);
                db.close();
                return;
            }
            if (doc != null) {
                result.push(doc);
            } else {
                callback(null, result);
                db.close();
            }
        });
    });
}


exports.updateMany = function (collectionName, json1, json2, callback) {
    connectDB(function (err, db) {
        const mydb = db.db("haha");
        mydb.collection(collectionName).updateMany(json1, json2, function (err, results) {
                callback(err, results);
                db.close();
            });
    })
}


