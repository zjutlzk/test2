var express = require("express");
var app = express();
var db = require("./model/db.js");
var formidable = require('formidable');
var crypto = require("crypto");
var cors = require('cors');
var session = require('express-session');
var path = require("path");
var fs = require("fs");
app.use(cors());
app.use(express.static("./public"));
app.set("view engine","ejs");
app.use(session({
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: true
}));
app.post("/tijiao", function (req, res, next) {
    var form = new formidable.IncomingForm();

    form.parse(req, function (err, fields) {
    	console.log("收到请求了");
        var md5 = crypto.createHash('md5');
        var subpasswd = md5.update(fields.password).digest('base64');

        db.find("user", {
            "username" : fields.username
        }, function (err, result) {
            if(err){
                console.log("出错了");
                res.send("-2");
                return;
            }
            if(result.length!=0){
                console.log("用户名被占用");
                res.send("-3");
                return;
            }else{
                db.insertOne("user", {
                    "username" : fields.username,
                    "password" : subpasswd,
                    "img" : "touxiang.jpg"
                }, function (err, result) {
                    if(err){
                        res.send("-1");
                        return;
                    }
                    console.log("注册成功");
                    req.session.login = "1";
                    req.session.username = fields.username;
                    res.send("1");
                });
            }

        });


    });
});

app.post("/update1", function (req, res, next) {
    var form = new formidable.IncomingForm();

    form.parse(req, function (err, fields) {
        console.log("收到请求了");
        var md5 = crypto.createHash('md5');
        var tpasswd = md5.update(fields.password).digest('base64');
        db.updateMany("user",{"username" : req.session.username}, {$set:{'password':tpasswd}},
                    function (err, result) {
                    if(err){
                        res.send("-1");
                        return;
                    }
                    console.log("修改成功");
                    res.send("1");
                });
        });

});

app.post("/login", function (req, res, next) {
    var form = new formidable.IncomingForm();

    form.parse(req, function (err, fields) {
        console.log("收到请求了");
        var md5 = crypto.createHash('md5');
        var subpasswd2 = md5.update(fields.password).digest('base64');
        db.find("user", {
            "username" : fields.username
        }, function (err, result) {
            var passwd = result[0].password;
            if(err){
                console.log("出错了");
                res.send({"result":-1});
                return;
            }
            if(passwd==subpasswd2){
                console.log("登陆成功");

                req.session.login = "1";
                req.session.username = fields.username;
                res.send("1");
            }else{
                res.send("-1");
                console.log("密码错误");
            }

        });
    });
});
app.get("/log",function (req, res, next) {
    res.render("login");
});
app.get("/",function (req, res, next) {
    if(req.session.login == "1"){
        db.find("user",{
            username : req.session.username
        },function(err,result){
           var touxiang = result[0].img || "touxiang.jpg";
            res.render("index",{
                "login":req.session.login == "1"?true:false,
                "username":req.session.login == "1"?req.session.username:"",
                "img":touxiang
            });
        });
    }else{
        res.render("index",{
            "login":req.session.login == "1"?true:false,
            "username":req.session.login == "1"?req.session.username:"",
            "img":"touxiang.jpg"
        });
    }

});

app.get("/reg",function (req, res, next) {
    res.render("register");
});

app.get("/tx",function (req, res, next) {
    res.render("tx",{
        "login":req.session.login = true,
        "username":req.session.login == "1"?req.session.username:"",
        "img":"touxiang.jpg"
    });
});

app.get("/aboutme",function (req, res, next) {
    res.render("aboutme",{
        "login":req.session.login = true,
        "username":req.session.login == "1"?req.session.username:"",
        "img":"touxiang.jpg"
    });
});

app.get("/update",function (req, res, next) {
    res.render("update",{
        "login":req.session.login = true,
        "username":req.session.login == "1"?req.session.username:"",
        "img":"touxiang.jpg"
    });
});

app.post("/dotx",function (req, res, next) {
    var form = new formidable.IncomingForm();
    form.uploadDir = "http:127.0.0.1:3000/public/touxiang/";
    console.log(form.uploadDir);
    form.parse(req,function(err,fields,files){

    });
});


app.listen(3000);